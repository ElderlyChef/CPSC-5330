//
//  ContentView.swift
//  Module3_CalculatorScreen
//
//  Created by user250833(Jonathan Elder) on on 1/26/24.
//

import SwiftUI

struct ContentView: View {
    
    @State private var result = "0"

    var body: some View {
        VStack(spacing: 8) {
            
            // Result View
            Text(result)
                .font(.system(size: 64))
                .frame(minWidth: 0, maxWidth: .infinity)
                .padding()
                .background(Color.gray)
                .foregroundColor(.white)

            // Top Row
            HStack(spacing: 6) {
                createButton("AC")
                createButton("C")
                createButton("+/-")
                createButton("Del")
            }

            // Second Row
            HStack(spacing: 6) {
                createButton("7")
                createButton("8")
                createButton("9")
                createButton("*")
            }
            
            // Third Row
            HStack(spacing: 6) {
                createButton("4")
                createButton("5")
                createButton("6")
                createButton("-")
            }
            
            // Fourth Row
            HStack(spacing: 6) {
                createButton("1")
                createButton("2")
                createButton("3")
                createButton("+")
            }
            
            // Last Row
            HStack(spacing: 6) {
                createButton("0")
                createButton(".")
                createButton("%")
                createButton("=")
            }
        }
        .padding()
    }

    func createButton(_ title: String) -> some View {
        Button(action: {
            buttonTapped(title)
        }) {
            Text(title)
                .font(.system(size: 24))
                .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity)
                .background(Color.gray)
                .cornerRadius(8)
                .foregroundColor(.white)
        }
    }

    func buttonTapped(_ title: String) {
        
        // Handle button tap. Not needed for this assignment.
        result = title
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
