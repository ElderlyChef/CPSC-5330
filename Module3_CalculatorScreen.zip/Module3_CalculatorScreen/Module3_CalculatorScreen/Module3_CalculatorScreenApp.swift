//
//  Module3_CalculatorScreenApp.swift
//  Module3_CalculatorScreen
//
//  Created by user250833(Jonathan Elder) on 1/26/24.
//

import SwiftUI

@main
struct Module3_CalculatorScreenApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
