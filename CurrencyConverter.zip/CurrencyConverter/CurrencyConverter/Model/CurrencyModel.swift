//
//  CurrencyModel.swift
//
//  ViewController.swift
//  CurrencyConverter Module 6 Project
//  Jonathan Elder
//  2/22/2024
//

import Foundation

class CurrencyModel {
    
    // Define exchange rates for the currencies
    private let exchangeRates: [Double] = [0.9, 110, 0.75, 1.25]
    
    func convert(amount: Int, currencies: [Bool]) -> [String] {
        var conversionResults = [String]()
        
        for (index, currencySelected) in currencies.enumerated() {
            if currencySelected {
                // Perform the conversion
                let convertedAmount = Double(amount) * exchangeRates[index]
                // Format the result to a string with 2 decimal places
                conversionResults.append(String(format: "%.2f", convertedAmount))
            } else {
                // If the currency isn't selected, append an empty string
                conversionResults.append("--")
            }
        }
        
        return conversionResults
    }
}
