//
//  SecondViewController.swift
//
//  ViewController.swift
//  CurrencyConverter Module 6 Project
//  Jonathan Elder
//  2/22/2024
//


import UIKit

class SecondViewController: UIViewController {
    
    
    @IBOutlet weak var currency1Label: UILabel!
    @IBOutlet weak var currency2Label: UILabel!
    @IBOutlet weak var currency3Label: UILabel!
    @IBOutlet weak var currency4Label: UILabel!
    
    var convertedCurrency1: String?
    var convertedCurrency2: String?
    var convertedCurrency3: String?
    var convertedCurrency4: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set the labels with the converted amounts
        currency1Label.text = "Euro: \(convertedCurrency1 ?? "--")"
        currency2Label.text = "Japanese Yen: \(convertedCurrency2 ?? "--")"
        currency3Label.text = "British Pound Sterling: \(convertedCurrency3 ?? "--")"
        currency4Label.text = "Canadian Dollar: \(convertedCurrency4 ?? "--")"
    }

}
