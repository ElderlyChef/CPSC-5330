//
//  ViewController.swift
//  CurrencyConverter Module 6 Project
//  Jonathan Elder
//  2/22/2024
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var usdTextField: UITextField!
    @IBOutlet weak var currency1Switch: UISwitch!
    @IBOutlet weak var currency2Switch: UISwitch!
    @IBOutlet weak var currency3Switch: UISwitch!
    @IBOutlet weak var currency4Switch: UISwitch!
    
    // Initialize the model
    let currencyModel = CurrencyModel()
    
    @IBAction func convertButtonTapped(_ sender: Any) {
        // Validate the input and perform the conversion if the input is valid
        if let usdAmountText = usdTextField.text, !usdAmountText.isEmpty, let usdAmount = Int(usdAmountText) {
            // Prepare the currency selection state array
            let selectedCurrencies = [currency1Switch.isOn, currency2Switch.isOn, currency3Switch.isOn, currency4Switch.isOn]
            
            // Perform the conversion
            let conversionResults = currencyModel.convert(amount: usdAmount, currencies: selectedCurrencies)
            
            // Segue to the SecondViewController with the results
            performSegue(withIdentifier: "showConversionResult", sender: conversionResults)
        } else {
            // If input is not valid, you could handle the error here later
            // For now, you can just return or present an alert
            return
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showConversionResult" {
            guard let destinationVC = segue.destination as? SecondViewController,
                  let conversionResults = sender as? [String] else {
                // If the destination is not SecondViewController or sender is not [String], don't proceed.
                print("Segue preparation failed due to incorrect destinationVC or sender type.")
                return
            }
            
            // Safely unwrapped and confirmed types, now assign the values
            if conversionResults.count >= 4 {
                // Assign converted values if all four are present, otherwise assign nil
                destinationVC.convertedCurrency1 = conversionResults.count > 0 ? conversionResults[0] : nil
                destinationVC.convertedCurrency2 = conversionResults.count > 1 ? conversionResults[1] : nil
                destinationVC.convertedCurrency3 = conversionResults.count > 2 ? conversionResults[2] : nil
                destinationVC.convertedCurrency4 = conversionResults.count > 3 ? conversionResults[3] : nil
            } else {
                print("Not enough conversion results to display.")
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        usdTextField.text = "100"
        
    }


}

