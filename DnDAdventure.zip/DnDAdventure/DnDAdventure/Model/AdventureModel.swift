//
//  AdventureModel.swift
//  DnDAdventure
//
//  Created by user230773 on 2/13/24.
//  Jonathan Elder CPSC 5330 - Module 5
//

import Foundation

// Represents a step in the adventure with a description and choices.
struct AdventureStep {
    var id: String // Unique identifier for each step
    var description: String
    var choices: [AdventureChoice]
}

// Represents a choice within a step, including a description,
// the identifier of the next step it leads to, and whether it's a successful outcome.
struct AdventureChoice {
    var description: String
    var nextStepID: String? // ID of the next step; nil means this choice ends the adventure
    var isSuccessful: Bool // Indicates if this choice leads to a successful outcome of the adventure
}

// Manages the data for the adventure, including all steps and choices.
class AdventureData {
    static let shared = AdventureData()
    
    var steps: [String: AdventureStep] = [:]
    
    private init() {
        setupAdventure()
    }
    
    private func setupAdventure() {
        // Define the all of my steps for the adventure.
        // Final outcomes
        let treasureFound = AdventureStep(id: "treasureFound", description: "You've found the treasure! Your quest is complete.", choices: [])
        let lostAtSea = AdventureStep(id: "lostAtSea", description: "Oh no! You've lost your way and your journey ends here.", choices: [])
        let lostInStorm = AdventureStep(id: "lostInStorm", description: "The plane was overtaken by the storm. You did not make it.", choices: [])
        let treasureMissed = AdventureStep(id: "treasureMissed", description: "You arrive too late, and the treasure is gone.", choices: [])
        
        // Choices after hiring a boat captain.
        let hireBoatChoices = [
            AdventureChoice(description: "Sail through the treacherous waters", nextStepID: "lostAtSea", isSuccessful: false),
            AdventureChoice(description: "Take the longer, safer route", nextStepID: "treasureFound", isSuccessful: true)
        ]
        
        // Choices after hiring a flight pilot.
        let hireFlightChoices = [
            AdventureChoice(description: "Fly directly over the storm", nextStepID: "lostInStorm", isSuccessful: false),
            AdventureChoice(description: "Detour around the storm, risking being late", nextStepID: "treasureMissed", isSuccessful: false)
        ]
        
        // Initial decision node.
        let startChoices = [
            AdventureChoice(description: "Hire a private boat captain", nextStepID: "hireBoat", isSuccessful: false),
            AdventureChoice(description: "Hire a private flight pilot", nextStepID: "hireFlight", isSuccessful: false)
        ]
        
        // Starting step.
        let startStep = AdventureStep(id: "start", description: "You found the map of 'The Treasure on Pirate Island'. How will you get there?", choices: startChoices)
        
        // Hiring steps
        let hireBoatStep = AdventureStep(id: "hireBoat", description: "You've hired a sturdy boat and a seasoned captain. Which route will you take?", choices: hireBoatChoices)
        let hireFlightStep = AdventureStep(id: "hireFlight", description: "You've hired a skilled pilot. How will you navigate the storm?", choices: hireFlightChoices)
        
        // Populating the steps dictionary.
        steps = [
            startStep.id: startStep,
            hireBoatStep.id: hireBoatStep,
            hireFlightStep.id: hireFlightStep,
            treasureFound.id: treasureFound,
            lostAtSea.id: lostAtSea,
            lostInStorm.id: lostInStorm,
            treasureMissed.id: treasureMissed
        ]
    }
}
