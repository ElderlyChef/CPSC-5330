//
//  AdventureViewController.swift
//  DnDAdventure
//
//  Created by user230773 on 2/13/24.
//  Jonathan Elder CPSC 5330 - Module 5
//

import UIKit

class AdventureViewController: UIViewController {
    
    
    @IBOutlet weak var adventureDescriptionLabel: UILabel!
    
    @IBOutlet weak var choiceOne: UIButton!
    
    @IBOutlet weak var choiceTwo: UIButton!
    
    
    var currentStep: AdventureStep? {
        didSet {
            updateUI()
        }
    }
    
    var stepsDictionary: [String: AdventureStep] = AdventureData.shared.steps

    override func viewDidLoad() {
        super.viewDidLoad()
        currentStep = stepsDictionary["start"]
    }

    func updateUI() {
        DispatchQueue.main.async {
            self.adventureDescriptionLabel.text = self.currentStep?.description
            
            // Assumes there will always only be two choices.
            if let choices = self.currentStep?.choices, choices.count == 2 {
                self.choiceOne.setTitle(choices[0].description, for: .normal)
                self.choiceOne.isHidden = false
                self.choiceOne.tag = 0 // Assign tag for identification
                
                self.choiceTwo.setTitle(choices[1].description, for: .normal)
                self.choiceTwo.isHidden = false
                self.choiceTwo.tag = 1 // Assign tag for identification
            } else {
                self.choiceOne.isHidden = true
                self.choiceTwo.isHidden = true
            }
        }
    }

    @IBAction func choiceButtonTapped(_ sender: UIButton) {
        guard let choices = currentStep?.choices, sender.tag < choices.count else { return }

        let choice = choices[sender.tag]
        if let nextStepID = choice.nextStepID, let nextStep = stepsDictionary[nextStepID] {
            currentStep = nextStep
        } else {
            let message = choice.isSuccessful ? "Victory! Your adventure ends with success." : "Defeat! Your journey ends here."
            let alert = UIAlertController(title: "Adventure Over", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Restart", style: .default) { _ in
                self.currentStep = self.stepsDictionary["start"]
            })
            present(alert, animated: true)
        }
    }
}
