//
//  CityModel.swift
//  Module7Project
//
//
//

import Foundation

struct City {
    let name: String
    let state: String
    let population: Int
    let yearEstablished: Int
    
    // Cities to be filled into the tableview
    static let allCities: [City] = [
        City(name: "Auburn", state: "AL", population: 66000, yearEstablished: 1839),
        City(name: "Atlanta", state: "GA", population: 488800, yearEstablished: 1847),
        City(name: "Chicago", state: "IL", population: 2706000, yearEstablished: 1833),
        City(name: "New York", state: "NY", population: 8419000, yearEstablished: 1624),
        City(name: "Los Angeles", state: "CA", population: 3990000, yearEstablished: 1781),
        City(name: "Austin", state: "TX", population: 950000, yearEstablished: 1839),
        City(name: "Tucson", state: "AZ", population: 540000, yearEstablished: 1775),
        City(name: "Springfield", state: "IL", population: 116000, yearEstablished: 1821),
        City(name: "Charleston", state: "SC", population: 150000, yearEstablished: 1670),
        City(name: "Boulder", state: "CO", population: 107000, yearEstablished: 1859)
    ]
    
    static func getCity(at index: Int) -> City? {
        if index >= 0 && index < allCities.count {
            return allCities[index]
        } else {
            return nil
        }
    }
}
