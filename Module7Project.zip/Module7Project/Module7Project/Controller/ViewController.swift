//
//  ViewController.swift
//  Module7Project
//
//  
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
    }
    // Implement UITableViewDataSource methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return City.allCities.count // Return the number of cities
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // Dequeue a reusable cell
        let cell = tableView.dequeueReusableCell(withIdentifier: "CityCell", for: indexPath)
        let city = City.allCities[indexPath.row]
        cell.textLabel?.text = city.name
        cell.detailTextLabel?.text = city.state
        return cell
    }
    
    // Implement UITableViewDelegate method
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // Perform the segue with the selected city
        performSegue(withIdentifier: "showCityDetails", sender: City.allCities[indexPath.row])
    }
    
    // Prepare for the segue to SecondViewController
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showCityDetails",
           let destinationVC = segue.destination as? SecondViewController,
           let city = sender as? City {
            destinationVC.city = city
        }
    }
}

