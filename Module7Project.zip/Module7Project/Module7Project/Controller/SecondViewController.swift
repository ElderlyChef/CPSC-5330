//
//  SecondViewController.swift
//  Module7Project
//
//
//

import UIKit

class SecondViewController: UIViewController {
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var populationLabel: UILabel!
    @IBOutlet weak var yearEstablishedLabel: UILabel!

    var city: City?

    override func viewDidLoad() {
        super.viewDidLoad()
        nameLabel.text = city?.name
        populationLabel.text = "Population: \(city?.population ?? 0)"
        yearEstablishedLabel.text = "Established: \(city?.yearEstablished ?? 0)"
    }
}
