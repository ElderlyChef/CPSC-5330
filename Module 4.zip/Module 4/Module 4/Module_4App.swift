//
//  Module_4App.swift
//  Module 4
//
//  Created by user250833 on 2/7/24.
//

import SwiftUI

@main
struct Module_4App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
