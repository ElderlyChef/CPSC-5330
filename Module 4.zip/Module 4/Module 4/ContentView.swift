import SwiftUI
import AVFoundation

struct ContentView: View {
    @State private var currentDate = Date()
    @State private var selectedHours = 0
    @State private var selectedMinutes = 0
    @State private var timer: Timer?
    @State private var remainingTime = 0
    @State private var isTimerRunning = false
    @State private var audioPlayer: AVAudioPlayer?

    var backgroundimageName: String {
        let hour = Calendar.current.component(.hour, from: Date())
        return hour < 12 ? "morningImage" : "eveningImage"
    }

    var body: some View {
        VStack(spacing: 20) {
            Text(currentDate.formatted(.dateTime.weekday(.abbreviated).day().month(.abbreviated).year().hour().minute().second()))
                .font(.largeTitle)
                .onAppear(perform: startLiveClock)
            
            HStack {
                Picker("Hours", selection: $selectedHours) {
                    ForEach(0..<24, id: \.self) { hour in
                        Text("\(hour) hr").tag(hour)
                    }
                }
                .pickerStyle(WheelPickerStyle())
                .frame(width: UIScreen.main.bounds.width / 3, height: 100)
                .compositingGroup()
                .clipped()
                
                Picker("Minutes", selection: $selectedMinutes) {
                    ForEach(0..<60, id: \.self) { minute in
                        Text("\(minute) min").tag(minute)
                    }
                }
                .pickerStyle(WheelPickerStyle())
                .frame(width: UIScreen.main.bounds.width / 3, height: 100)
                .compositingGroup()
                .clipped()
            }
            
            Text("Remaining Time: \(formatTimeInterval(remainingTime))")
                .font(.title)
            
            Button(isTimerRunning ? "Stop Timer" : "Start Timer") {
                if isTimerRunning {
                    stopTimer()
                } else {
                    startTimer()
                }
            }
        }
        .padding()
        .background(
            Image(backgroundimageName)
                .resizable()
                .aspectRatio(contentMode: .fill)
                .edgesIgnoringSafeArea(.all)
        )
    }
    
    // Timer functionality
    func startLiveClock() {
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            self.currentDate = Date()
        }
    }
    
    func startTimer() {
        timer?.invalidate()
        isTimerRunning = true
        remainingTime = totalDurationInSeconds
        
        // Start the countdown timer
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            if self.remainingTime > 0 {
                self.remainingTime -= 1
            } else {
                self.stopTimer()
                self.playMusic()
            }
        }
    }
    
    func stopTimer() {
        timer?.invalidate()
        timer = nil
        isTimerRunning = false
        remainingTime = totalDurationInSeconds
    }
    
    // Helper functions
    var totalDurationInSeconds: Int {
        return selectedHours * 3600 + selectedMinutes * 60
    }
    
    func formatTimeInterval(_ timeInterval: Int) -> String {
        let hours = timeInterval / 3600
        let minutes = (timeInterval % 3600) / 60
        let seconds = timeInterval % 60
        return String(format: "%02i:%02i:%02i", hours, minutes, seconds)
    }
    
    // Music playback
    func playMusic() {
        // Make sure my music file I include from my project is in assets.
        guard let url = Bundle.main.url(forResource: "alarmSound", withExtension: "mp3") else {
            print("Unable to find music file.")
            return
        }
        
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer?.play()
        } catch {
            print("Unable to play music. Error: \(error.localizedDescription)")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
